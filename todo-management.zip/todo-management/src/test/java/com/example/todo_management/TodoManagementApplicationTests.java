package com.example.todo_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
